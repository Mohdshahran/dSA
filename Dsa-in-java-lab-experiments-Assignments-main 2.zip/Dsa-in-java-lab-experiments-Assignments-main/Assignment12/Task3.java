package Assignment12;

public class Task3 {

    static int power(int base, int exp) {

        if (exp == 0) {
            return 1; // Base case
        }

        return base * power(base, exp - 1);
    }

    public static void main(String[] args) {

        System.out.println("Power: " + power(2, 5));
    }
}