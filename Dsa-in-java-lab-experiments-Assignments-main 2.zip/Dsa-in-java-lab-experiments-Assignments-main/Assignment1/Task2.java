package Assignment1;

public class Task2 {
    public static void main(String[] args) {

        int[] marks = { 45, 67, 80, 52, 90 };

        for (int i = 0; i < marks.length; i++) {
            System.out.println(marks[i]);
        }
    }
}
