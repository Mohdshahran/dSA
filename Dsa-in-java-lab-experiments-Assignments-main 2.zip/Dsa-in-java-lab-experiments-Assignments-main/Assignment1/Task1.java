package Assignment1;

public class Task1 {
    public static void main(String[] args) {

        int[] marks = { 45, 67, 80, 52, 90 };

        System.out.println("First: " + marks[0]);
        System.out.println("Last: " + marks[4]);
    }
}
