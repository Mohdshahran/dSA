package Assignment2;

public class Task3 {
    public static void main(String[] args) {

        int[] marks = { 45, 67, 80, 52, 90 };

        int count = 0;

        for (int i = 0; i < marks.length; i++) {

            if (marks[i] > 60) {
                count++;
            }
        }

        System.out.println("Count: " + count);
    }
}